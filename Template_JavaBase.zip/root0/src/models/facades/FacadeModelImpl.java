package models.facades;

public class FacadeModelImpl implements FacadeModel {
}
