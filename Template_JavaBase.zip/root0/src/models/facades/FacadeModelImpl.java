package models.facades;

import models.exception.ExceptionModel;

public class FacadeModelImpl implements FacadeModel {
}
