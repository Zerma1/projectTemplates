package models.facades;

public interface FacadeModel {
}
