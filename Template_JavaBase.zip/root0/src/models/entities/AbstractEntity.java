package models.entities;

public abstract class AbstractEntity throws ExceptionEntity {

    private Long id;

    public void setId(Long id) {
        this.id = id;
    }
}
