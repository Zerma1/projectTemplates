package models.entities;

import models.exception.ExceptionEntity;

public abstract class AbstractEntity{

    private Long id;

    public void setId(Long id) {
        this.id = id;
    }
}
