package models.entities.enums;

public enum Enume {
    UN,
    DEUX,
    TROIS,
    QUATRE
}
