package models.entities;

import models.exception.ExceptionFactory;

public final class EntitiesFactory {

    private EntitiesFactory() {}
}
