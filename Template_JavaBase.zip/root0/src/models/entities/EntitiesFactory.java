package models.entities;

public final class EntitiesFactory throws ExceptionFactory {

    private EntitiesFactory() {}
}
