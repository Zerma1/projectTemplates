package models.entities;

public final class EntitiesFactory {

    private EntitiesFactory() {}
}
