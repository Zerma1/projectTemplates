package models.exception;

public class ExceptionModel extends RuntimeException {
    public ExceptionModel(String message) {
        super("Model-"+message);
    }
}
