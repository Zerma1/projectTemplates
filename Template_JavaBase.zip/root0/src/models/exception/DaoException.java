package models.exception;

public class DaoException extends RuntimeException {
    public DaoException(String message) {
        super("Dao-"+message);
    }
}
