package models.exception;

public class ExceptionDao extends RuntimeException {
    public ExceptionDao(String message) {
        super("Dao-"+message);
    }
}
