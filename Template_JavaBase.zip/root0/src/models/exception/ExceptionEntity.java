package models.exception;

public class ExceptionEntity extends RuntimeException {
    public ExceptionEntity(String message) {
        super("entity-"+message);
    }
}
