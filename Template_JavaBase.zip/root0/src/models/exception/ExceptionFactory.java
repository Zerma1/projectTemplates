package models.exception;

public class ExceptionFactory extends RuntimeException {
    public ExceptionFactory(String message) {
        super("Factory-"+message);
    }
}
