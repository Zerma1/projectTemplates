package models.exception;

public class Exception extends RuntimeException {
    public Exception(String message) {
        super("EX-"+message);
    }
}
