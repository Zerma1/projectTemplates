package models.dao.implDao;

import models.dao.Dao;
import models.exception.DaoException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public abstract class AbstractDaoImpl<T> implements Dao<T> {

    protected Map<Long, T> persistant = new HashMap<>();

    private Long Increment = 0L;

    private Long incrementationPersistant() {
        return ++Increment;
    }

    @Override
    public T save(T entity) {
        if (entity == null) {
            throw new DaoException("Entity cannot be null");
        }
        return persistant.put(incrementationPersistant(), entity);
    }

    @Override
    public T findById(Long id) {
        T entity = persistant.get(id);
        if (entity == null) {
            throw new DaoException("Entity not found for id: " + id);
        }
        return entity;
    }

    @Override
    public T update(Long id, T entity) {
        if (!persistant.containsKey(id)) {
            throw new DaoException("Entity not found for id: " + id);
        }
        return persistant.put(id, entity);
    }

    @Override
    public void deleteAll() {
        persistant.clear();
    }

    @Override
    public Iterable<T> readAll() {
        return Collections.unmodifiableCollection(persistant.values());
    }

    @Override
    public boolean delete(Long id) {
        if (!persistant.containsKey(id)) {
            throw new DaoException("Entity not found for id: " + id);
        }
        return persistant.remove(id) != null;
    }

    @Override
    public boolean exist(Long id) {
        return persistant.containsKey(id);
    }

    @Override
    public int count() {
        return persistant.size();
    }
}