package models.dao;

import models.exception.ExceptionFactory;

public final class DaoFactory {
    private DaoFactory() {}
}
