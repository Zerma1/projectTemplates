package views.facades;

public interface FacadeView {
    void printException(String message);
}
