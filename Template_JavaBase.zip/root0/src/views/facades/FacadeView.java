package views.facades;

public interface FacadeView {
}
