package views.facades;

import views.utlis.UtilPrint;
import views.utlis.UtilRead;
import views.utlis.UtilView;

public class FacadeViewImpl implements FacadeView {
}
