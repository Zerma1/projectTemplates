package views.facades;

import views.utils.UtilPrint;
import views.utils.UtilRead;
import views.utils.UtilView;

public class FacadeViewImpl implements FacadeView {
    @Override
    public void printException(String message) {
        UtilPrint.printErreur("EX-" + message);
        UtilPrint.printErreur("Please, try again.");
        UtilPrint.printErreur("If the problem persists, contact support.");
        UtilPrint.printErreur("Press any key to continue...");
        UtilRead.readString();
        UtilView.clearScreen();
    }
}
