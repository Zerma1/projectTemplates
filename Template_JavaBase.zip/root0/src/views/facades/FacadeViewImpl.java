package views.facades;

import views.utils.UtilPrint;
import views.utils.UtilRead;
import views.utils.UtilView;


public class FacadeViewImpl implements FacadeView {
    @Override
    public void printException(String message) {
        UtilPrint.printErreur("EX-" + message);
        UtilPrint.printErreur("Veuillez réessayer.");
        UtilPrint.printErreur("Si le problème persiste, contactez le support.");
        UtilPrint.printErreur("Appuyez sur une touche pour continuer...");
        UtilRead.readString();
        UtilView.clearScreen();
    }
}
