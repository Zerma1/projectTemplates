package views;

public class ConstanceView {
}
