package views.utils;

import java.util.*;

public class UtilView {
    public static <E extends Enum<E>> List<String> enumToList(Class<E> enumClass) {
        List<String> list = new ArrayList<String>();

        for(E e : enumClass.getEnumConstants()){
            list.add(e.name());
        }
        return list;
    }

    public static void clearScreen() {
        try {
            if (System.getProperty("os.name").contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                new ProcessBuilder("clear").inheritIO().start().waitFor();
            }
        } catch (Exception e) {
            System.out.println("Error clearing screen: " + e.getMessage());
        }
    }
}
