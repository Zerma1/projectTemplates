package models.entities.referances;

public enum Enume {
    UN,
    DEUX,
    TROIS,
    QUATRE
}
