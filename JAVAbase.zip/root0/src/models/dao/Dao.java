package models.dao;

public interface Dao {
}
