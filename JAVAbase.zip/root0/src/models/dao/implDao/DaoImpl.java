package models.dao.implDao;

import models.dao.Dao;

public class DaoImpl implements Dao {
}
