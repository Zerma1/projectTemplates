package models.exeption;

public class Exeption extends RuntimeException {
    public Exeption(String message) {
        super(message);
    }
}
