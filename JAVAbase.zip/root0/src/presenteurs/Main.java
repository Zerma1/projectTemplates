package presenteurs;

import models.facades.FacadeModel;
import models.facades.FacadeModelImpl;
import views.facades.FacadeView;
import views.facades.FacadeViewImpl;

public class Main {
    public static void main(String[] args) {
        FacadeView view = new FacadeViewImpl();
        FacadeModel model = new FacadeModelImpl();

        Presenteur presenteur = new Presenteur(view, model);

        presenteur.start();
    }
}