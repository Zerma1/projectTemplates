package presenteurs;

import models.facades.FacadeModel;
import views.facades.FacadeView;

public class Presenteur {
    FacadeView view;
    FacadeModel model;

    public void setView(FacadeView view) {
        this.view = view;
    }

    public void setModel(FacadeModel model) {
        this.model = model;
    }

    public Presenteur(FacadeView view, FacadeModel model) {
        setView(view);
        setModel(model);
    }

    public void start(){

    }
}
