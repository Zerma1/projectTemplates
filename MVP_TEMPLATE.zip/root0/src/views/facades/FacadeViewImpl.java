package views.facades;

public class FacadeViewImpl implements FacadeView {
}
